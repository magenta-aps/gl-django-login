from django.apps import AppConfig


class LoginConfig(AppConfig):
    name = 'django_mitid_auth'
